#!/usr/bin/env python3
"""
scripts/rayyan-fetch.py
=======================
Collecte les données Rayyan et génère src/data/scoping-review.yaml
pour le site Astro (NKG_online).

Usage :
  python scripts/rayyan-fetch.py --creds creds.json --review-id <ID>
  python scripts/rayyan-fetch.py --creds creds.json              # liste les reviews

Prérequis :
  pip install rayyan-sdk pyyaml
"""

import argparse
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    import yaml
except ImportError:
    print("❌ PyYAML manquant. Lancez : pip install pyyaml")
    sys.exit(1)

try:
    from rayyan import Rayyan
except ImportError:
    print("❌ SDK Rayyan manquant. Lancez : pip install rayyan-sdk")
    sys.exit(1)


OUTPUT_PATH = Path("src/data/scoping-review.yaml")


def list_reviews(rayyan: Rayyan):
    """Affiche la liste des reviews accessibles."""
    print("📋 Vos reviews Rayyan :\n")
    all_reviews = rayyan.review.get_all()
    reviews = all_reviews.get("owned_reviews", []) + all_reviews.get("collab_reviews", [])
    for r in reviews:
        print(f"  [{r.get('id')}] {r.get('title', 'Sans titre')}"
              f"  ({r.get('total_articles', '?')} articles)")
    if not reviews:
        print("  Aucune review trouvée.")
    print(f"\n💡 Relancez avec --review-id <ID>")


def fetch_and_generate(rayyan: Rayyan, review_id: int, output: Path):
    """Récupère les données et génère le YAML."""

    # 1 — Infos de base
    print(f"📖 Récupération de la review #{review_id}...")
    review = rayyan.review.get(review_id)
    title = review.get("title", "Scoping Review")
    total = review.get("total_articles", 0)
    print(f"   {title} — {total} articles")

    # 2 — Compteurs d'inclusion
    print("📊 Compteurs d'inclusion...")
    counts = rayyan.review.inclusion_counts(review_id)

    # 3 — Facettes
    print("🏷️  Facettes...")
    facets = rayyan.review.facets(review_id)

    # 4 — Construire le YAML
    # Note : la structure exacte des réponses API peut varier.
    # Le bloc ci-dessous extrait ce qu'il peut et met des valeurs par défaut.
    included = 0
    excluded = 0
    maybe = 0
    if isinstance(counts, dict):
        included = counts.get("included", 0)
        excluded = counts.get("excluded", 0)
        maybe = counts.get("maybe", 0)

    screened = included + excluded + maybe
    # Les doublons et le total unique sont parfois dans les facettes
    duplicates = 0
    if isinstance(facets, dict):
        dup_facet = facets.get("duplicates", {})
        if isinstance(dup_facet, dict):
            duplicates = dup_facet.get("total", 0)

    unique = total - duplicates

    # Reviewers — l'API inclusion_counts avec user_id=0 donne l'agrégé.
    # Pour chaque reviewer, il faudrait itérer sur les user IDs.
    # On prépare la structure, à compléter avec les vrais IDs.
    reviewers_data = []
    users = review.get("users", [])
    for u in users:
        uid = u.get("id", 0)
        uname = u.get("name", "Inconnu")
        try:
            uc = rayyan.review.inclusion_counts(review_id, user_id=uid)
            reviewers_data.append({
                "name": uname,
                "screened": uc.get("included", 0) + uc.get("excluded", 0) + uc.get("maybe", 0),
                "included": uc.get("included", 0),
                "excluded": uc.get("excluded", 0),
                "maybe": uc.get("maybe", 0),
            })
        except Exception:
            reviewers_data.append({
                "name": uname,
                "screened": 0,
                "included": 0,
                "excluded": 0,
                "maybe": 0,
            })

    data = {
        "meta": {
            "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "rayyan_review_id": review_id,
            "title": title,
            "type": review.get("review_type", "Scoping Review"),
            "created_at": review.get("created_at", ""),
        },
        "totals": {
            "imported": total,
            "duplicates_found": duplicates,
            "duplicates_resolved": duplicates,  # approx — API ne distingue pas toujours
            "duplicates_pending": 0,
            "unique": unique,
            "screened": screened,
            "not_screened": max(0, unique - screened),
            "included": included,
            "excluded": excluded,
            "maybe": maybe,
            "conflicts": counts.get("conflicts", 0) if isinstance(counts, dict) else 0,
        },
        "reviewers": reviewers_data,
        "sources": [],  # À enrichir via facets si disponible
        "weekly": [],   # Pas directement dans l'API — calculable par delta temporel
    }

    # 5 — Écriture
    output.parent.mkdir(parents=True, exist_ok=True)

    header = (
        "# src/data/scoping-review.yaml\n"
        "# Généré automatiquement par scripts/rayyan-fetch.py\n"
        f"# Dernière mise à jour : {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
        "# Ne pas éditer à la main\n\n"
    )

    with open(output, "w", encoding="utf-8") as f:
        f.write(header)
        yaml.dump(data, f, allow_unicode=True, default_flow_style=False, sort_keys=False)

    print(f"\n✅ Fichier généré : {output}")
    print(f"   {total} articles · {screened} screenés · {included} inclus")
    if reviewers_data:
        print(f"   {len(reviewers_data)} reviewers détectés")


def main():
    parser = argparse.ArgumentParser(description="Rayyan → YAML pour le PhD Dashboard")
    parser.add_argument("--creds", default="creds.json", help="Fichier credentials Rayyan")
    parser.add_argument("--review-id", type=int, default=0, help="ID de la review (0 = lister)")
    parser.add_argument("--output", type=str, default=str(OUTPUT_PATH), help="Chemin de sortie YAML")
    args = parser.parse_args()

    print(f"🔗 Connexion à Rayyan...")
    rayyan = Rayyan(args.creds)
    user = rayyan.user.get_info()
    print(f"   Connecté : {user.get('name', 'N/A')}")

    if args.review_id == 0:
        list_reviews(rayyan)
    else:
        fetch_and_generate(rayyan, args.review_id, Path(args.output))


if __name__ == "__main__":
    main()

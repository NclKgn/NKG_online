# Scoping Review Dashboard — Package d'intégration

## Vue d'ensemble

Ce package ajoute un **dashboard de scoping review** alimenté par l'API Rayyan
au site Astro NKG_online. Il comprend :

```
src/data/scoping-review.yaml      ← Données (générées auto par le script)
src/components/ScopingDashboard.astro  ← Composant de visualisation
src/pages/phd/dashboard.astro     ← Page /phd/dashboard
scripts/rayyan-fetch.py           ← Script de collecte Rayyan → YAML
.github/workflows/rayyan-sync.yml ← GitHub Action (sync quotidienne)
```

## Installation

### 1. Copier les fichiers

Copier chaque fichier à sa place dans le repo NKG_online.

### 2. Ajouter un lien dans la page PhD

Dans `src/pages/phd/index.astro`, ajouter avant la section newsletter :

```astro
<section class="phd-dashboard-link">
  <h2>Dashboard</h2>
  <p>Suivi en temps réel de l'avancement de la scoping review.</p>
  <a href={base('/phd/dashboard')} class="mono">Voir le dashboard →</a>
</section>
```

### 3. Installer les dépendances Python (local)

```bash
pip install rayyan-sdk pyyaml
```

### 4. Obtenir les tokens Rayyan

1. Se connecter sur https://rayyan.ai
2. Aller sur https://rayyan.ai/users/edit
3. Copier l'access token et le refresh token
4. Créer `creds.json` à la racine du repo (ajouté au .gitignore) :

```json
{
  "access_token": "votre_access_token",
  "refresh_token": "votre_refresh_token"
}
```

### 5. Premier test local

```bash
# Lister vos reviews
python scripts/rayyan-fetch.py --creds creds.json

# Générer les données pour une review spécifique
python scripts/rayyan-fetch.py --creds creds.json --review-id 123456
```

### 6. Configurer la GitHub Action

Dans le repo GitHub, aller dans Settings → Secrets and variables :

**Secrets :**
- `RAYYAN_ACCESS_TOKEN` — votre access token
- `RAYYAN_REFRESH_TOKEN` — votre refresh token

**Variables :**
- `RAYYAN_REVIEW_ID` — l'ID numérique de votre review

La GitHub Action se lance automatiquement chaque jour à 7h (Paris)
ou manuellement via l'onglet Actions.

### 7. Ajouter creds.json au .gitignore

```
# dans .gitignore
creds.json
```

## Architecture

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│  Rayyan API  │────▶│ rayyan-fetch │────▶│ scoping-     │
│              │     │   .py        │     │ review.yaml  │
└──────────────┘     └──────────────┘     └──────┬───────┘
                                                  │
                     ┌──────────────┐     ┌───────▼──────┐
                     │  dashboard   │◀────│  ScopingDash │
                     │  .astro      │     │  board.astro │
                     └──────────────┘     └──────────────┘
```

La GitHub Action exécute le script Python quotidiennement,
commit le YAML mis à jour, ce qui déclenche le build Astro
et le déploiement sur GitHub Pages.

## Notes

- Le fichier `scoping-review.yaml` contient des données simulées par défaut.
  Il sera écrasé dès le premier run du script avec vos données réelles.
- L'API Rayyan peut avoir des limites de débit — le script fait ~5 appels par run.
- Les tokens expirent périodiquement. Si le script échoue, régénérez-les sur Rayyan.
